How to use Pdf To Djvu Gui : 
1. Just run Pdf To Djvu Gui. 
2. Load your pdf files
3. Press the convert button and wait :)
4. You are done

Tips : 
1. The output files are in the same location where pdf files are. 
Example : 
c:\mydocs\1.pdf 
c:\mydocs\1.djvu
2. A really nice djvu viewer is windjview ( http://windjview.sourceforge.net )
3. From the version 2.0 and above Pdf to Djvu GUI is portable.
4. The convertion is a slow so give some time.

About : 
Pdf To Djvu Gui is a freeware win32 application that converts any pdf into Djvu.
Djvu files are generally smaller than the pdf files and are good looking.
Pdf To Djvu Gui from the version 2.0 is portable and come to two flavors Windows and Linux.
Pdf To Djvu Gui is based on pdf2djvu ( http://code.google.com/p/pdf2djvu ).
    
Special thanks : 
I would like to thanks personally Jakub Wilk,the author of pdf2djvu, which responded to all of my questions. 
Without him this project would not be possible to make.  